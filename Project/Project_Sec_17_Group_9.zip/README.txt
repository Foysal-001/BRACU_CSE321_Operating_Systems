CSE 321: Operating Systems
SimpleFS Lab Term Project - Student Starter Files

FILES
1. simplefs.h          - fixed constants and structures; do not modify unless instructed.
2. simplefs_builder.c  - complete TODO 1 through TODO 6.
3. simplefs_adder.c    - complete TODO 1 through TODO 11.
4. test1.txt, test2.txt, test3.txt - simple sample input files.

COMPILE
gcc -Wall -Wextra -std=c11 simplefs_builder.c -o simplefs_builder
gcc -Wall -Wextra -std=c11 simplefs_adder.c -o simplefs_adder

RUN
./simplefs_builder --image disk.img
./simplefs_adder --input disk.img --file test1.txt

IMPORTANT
- Follow the official project specification for the exact layout and expected behavior.
- Source files must be in the current working directory.
- Maximum regular-file size is 12288 bytes.
- Implement only the clearly marked TODO sections.


=================================================================
Group No: 09
ID: 23201344

=================================================================
Compilation Commands:
gcc -Wall -Wextra -std=c11 simplefs_builder.c -o simplefs_builder
gcc -Wall -Wextra -std=c11 simplefs_adder.c -o simplefs_adder

=================================================================
Execution Examples:
./simplefs_builder --image disk.img
./simplefs_adder --input disk.img --file test1.txt

=================================================================
Brief Description of Implementation:
This project creates and manages a simple filesystem image using the provided
SimpleFS structure. The builder program creaters the filesystem and sets up 
the superblock, bitmaps, root inode and root directory. The adder program adds
files by finding available information. it also hanfles cases such as duplicate 
files missing files empty files that are too large. the implementation follows the 
given filesystem layout and project reqwuirement. 

=================================================================
contribution: 
ID: 23201344 ----- Whole project. 

=================================================================
No major known problems were found during testing. The implementation 
was tested with empty files, normal files, multiple files, multi-blocck files
,, duplicate filenames, missing files, invalid file system images, maximum
supported file size.